package lab1;

public class Driver {
	static Model model1;
	static Model model2;
	public static void main (String[] args) {
		model1  = new Model ("Frank", "Xue", 70, 120.0, 69, true, false);
		model2  = new Model ("Susan", "Smith", 70, 120.0, 69, true, false);
		model1.printDetails();
		model2.printDetails();
	}
	
}
