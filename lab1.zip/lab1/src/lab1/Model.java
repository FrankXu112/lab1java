package lab1;

/**
 * 
 * @author frankxu
 *
 */
public class Model {

	private String firstName;
	private String lastName;
	private int height;
	private double weight;
	private boolean canTravel;
	private boolean smoker;
	private int rate;
	private static String occupation = "modeling";

	public Model(){
		
	}
	
	public Model(String firstName, String lastName, int height, double weightKg, int rate, boolean traveler,
			boolean smoker) {

		setFirstName(firstName);
		setLastName(lastName);
		setHeightInches(height);
		setWeight(weightKg);
		setRate(rate);
		setCanTravel(traveler);
		setSmoker(smoker);
	}
	
	public Model(String firstName, String lastName, int height, double weight, int rate) {

		setFirstName(firstName);
		setLastName(lastName);
		setHeightInches(height);
		setWeight(weight);
		setRate(rate);
		setCanTravel(true);
		setSmoker(false);
	}

	/**
	 * @param
	 * 
	 * @param firstName
	 */
	public final void setFirstName(String firstName) {
		if ((firstName != null) && (firstName.length() >= 3) && (firstName.length() <= 20)) {
			this.firstName = firstName;
		}
	}

	/**
	 * @param
	 * 
	 * @param lastName
	 */
	public final void setLastName(String lastName) {
		if ((lastName != null) && (lastName.length() >= 3) && (lastName.length() <= 20)) {
			this.lastName = lastName;
		}
	}

	/**
	 * @param
	 * 
	 * @param height
	 */
	public final void setHeightInches(int heightInches) {
		if ((heightInches >= 24) && (heightInches <= 84)) {
			this.height = heightInches;
		}
	}

	/**
	 * @param
	 * 
	 * @param weight
	 */
	public final void setWeight(double pounds) {
		if ((pounds >= 80) && (pounds <= 280)) {
			this.weight = pounds;
		}
	}

	public final void setWeight(long kilograms) {
		this.weight = kilograms * 0.45359237;
	}

	/**
	 * @param
	 * 
	 * @param canTravel
	 */
	public final void setCanTravel(boolean canTravel) {
		this.canTravel = canTravel;
	}

	/**
	 * @param
	 * 
	 * @param smoker
	 */
	public final void setSmoker(boolean smoker) {
		this.smoker = smoker;
	}
	
	/**
	 * @param
	 * 
	 * @param rate
	 */
	public final void setRate(int rate) {
		this.rate = rate;
	}

	/**
	 * @return
	 * 
	 * @return
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @return
	 * 
	 * @return
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @return
	 * 
	 * @return
	 */
	public int getHeight() {
		return height;
	}
	
	/**
	 * 
	 * @return
	 */
	public String getHeightInFeetAndInches() {
		String feet = "";
		String inch = "";
		int ft = Math.round(this.getHeight() / 12);
		int in = this.getHeight() - ft * 12;
		feet = ft + " feet ";
		if(this.getHeight()%12 == 0) {
			return feet;
		}
		else {
			if (in == 1) {
				inch = in + " inch ";
				return feet + inch;
			}
			else {
				inch = in + " inches ";
				return feet + inch;
			}
		}
	}

	/**
	 * @return
	 * 
	 * @return
	 */
	public double getWeight() {
		Math.round(weight);
		return weight;
	}
	
	/**
	 * 
	 * @return
	 */
	public long getWeightKg() {
		long wk = (long)(this.getWeight() * 0.45359237);
		return wk;
	}
	
	/**
	 * 
	 * @return
	 */
	public int getRate() {
		return rate;
	}

	/**
	 * @return
	 * 
	 * @return
	 */
	public boolean getCanTravel() {
		return true;
	}

	/**
	 * @return
	 * 
	 * @return
	 */
	public boolean getSmoker() {
		return false;
	}
	
	/**
	 * 
	 * @return
	 */
	public static String getOccupation() {
		return occupation;
	}


	public void printDetails() {
		System.out.println("Name: " + getFirstName() + " " + getLastName());
		System.out.println("Height: " + getHeightInFeetAndInches());
		System.out.println("Weight: " + getWeightKg() + " kilograms");
		if (canTravel == true) {
			System.out.println("Does travel ");
		} else {
			System.out.println("Does not travel ");
		}
		if (smoker == true) {
			System.out.println("Does smoke ");
		} else {
			System.out.println("Does not smoke ");
		};
		System.out.println("Hourly rate: $" + getRate());
	}

	@Override
	public String toString() {
		return "Name: " + getFirstName() + " " + getLastName() + "Height: " + getHeightInFeetAndInches() +"Weight: " + getWeightKg() + " kilograms" + "Hourly rate: $" + getRate();

	}
}
